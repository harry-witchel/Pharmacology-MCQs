function logicalTF = isanumber(X)

%%%  THIS FUNCTION WILL RECOGNISE WHETHER X IS A NUMBER OR NOT.  IT WILL
%%%  BE FALSE FOR INFINITY OR NaN, BUT IT WILL BE TRUE FOR A SINGLE NUMBER THAT IS
%%%  INSIDE A CELL.  IT WILL BE FALSE FOR MATRICES, VECTORS, AND EMPTY VARIABLES.

logicalTF = false;

if ~isscalar(X) || ischar(X)
    return
    %%%  this gets rid of everything that is bigger than 1 x 1; note that a
    %%%  character string inside a cell is still considered 1 x 1
end;

%  if the input is a cell array, strip it out of the cell and see if it is
%  a scalar
if iscell(X) 
    %%%  by this point, the only cell arrays left are 1 x 1
    X = squeeze(X);
    %%%  a cell could contain anything including a matrix of numbers of
    %%%  another cell array
    
    insideX = X{1};
    if iscell(insideX) || ischar(insideX) || ~isscalar(insideX)
        return
        %%%  this gets rid of everything that is bigger than 1 x 1
        %%%  it also gets rid of cells inside cells
    end;
    X = insideX;
end;
%%%  by this point everything should be 1 x 1

if isnumeric(X) && isfinite(X)
    %%%  note that isnumeric will still be true for NaNs, inf, and matrices
    %%%  'isfinite' eliminates infinities and also NaNs
    logicalTF = true;
end;  %  if isnumeric(X) && isfinite(X)
