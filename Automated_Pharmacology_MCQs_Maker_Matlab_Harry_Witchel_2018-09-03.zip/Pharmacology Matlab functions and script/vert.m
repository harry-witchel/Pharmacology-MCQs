function output = vert(input)

%   The purpose of vert is to help sloppy programmers.
%   On occasion, when one invokes a function, it is not clear whether 
%   the output of that function will be a column vector or a row vector.
%   Vert allows the programmer to guaratee that the ultimate output is 
%   a column vector, which can be handled in downstream programming as
%   a column.  Obviously, to make a row vector consistently, just follow
%   vert with a '

if nargin ~= 1
    error('Error: vert must have only one input argument. \n\n');
end;  %  if nargin ~= 1
if size(size(input)) ~= 2
    error('Error: the input to vert must be a matrix or cell array of two dimensions. \n\n');
end;  %  if size(size(input)) ~= 2

if size(input,1) < size(input, 2)
    output = input';      %    swap rows for columns
else
    output = input;       %    input and output are the same
end