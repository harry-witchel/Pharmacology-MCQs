function output = dateToday()

output = datestr(now,29);