function [yesNoAllNines, negativeOnlyAllNines] = allnines(input)

%   This function detects whether all the digits in a single entry are
%   nines.  That is, is the number 99, -99, 999, -999, 9999, -9999, etc..
%   This is useful if a numerical table (e.g. in Excel) does not support
%   text such as N/A, or where 999 is coded for "NOT DONE".  The reason one
%   needs this function is in case you do not remember which combination of
%   nines have been used.  Note that the numbers, 9, -9 and any decimals do
%   not count as nines.

if nargin > 1
    error('Error: Number of arguments into to allnines is incorrect.')
end

if iscell(input)
    input = cell2mat(input);
end;  %  if iscell(input)

if ischar(input)
    input = str2double(input);
    if isempty(input)
        error('Error: The string input to allnines is not a legal number.')
    end
end

% if any(size(input)>1)
%     error('Error: The size of inputs to allnines needs to be scalar.')
% end

inputPlusOne = abs(input) + 1;
inputIsNegative = input < 0;
yesNoAllNines = ~(mod(log10(inputPlusOne),1) > 0); % test that log is an integer value
yesNoAllNines = (inputPlusOne > 98) & yesNoAllNines;
negativeOnlyAllNines = inputIsNegative & yesNoAllNines;


    